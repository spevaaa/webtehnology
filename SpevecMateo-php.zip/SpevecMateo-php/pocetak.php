<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Tesla Y</title>
        <link rel="stylesheet" type="text/css" href="stil.css">
        
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Alkatra&display=swap" rel="stylesheet">
    </head>
    <body>
        <header>
            <img src="Slike/bg.jpg">
        </header>
        
        <nav>
            <ul>
                <li><a href="index.php">Početna</a></li>
                <li><a href="teslax.php">Tesla X</a></li>
                <li><a href="teslay.php">Tesla Y</a></li>
            </ul>
        </nav>
        
        <main>