<?php include "pocetak.php" ?>
            <h1>Tesla Model X</h1>
            <p>Tesla Model X je baterijski električni luksuzni crossover SUV srednje veličine koji proizvodi Tesla, Inc. od 2015. Razvijeno iz limuzinske platforme pune veličine Tesla Model S, vozilo je poznato po tome što koristi vrata s krilima sokola za pristup putnika.</p>
            <p>Model X ima EPA klasu veličine kao SUV, i dijeli oko 30 posto svog sadržaja s Modelom S, polovicu od prvotno planiranih 60 posto, i teži oko 10 posto više. I Model X i Model S proizvode se u tvornici Tesla u Fremontu u Kaliforniji.</p>
            <p>Prototip je predstavljen u Teslinom dizajnerskom studiju u Hawthorneu, u Kaliforniji, 9. veljače 2012. Prve isporuke Modela X počele su u rujnu 2015. Nakon godinu dana na tržištu, 2016., Model X zauzeo je sedmo mjesto među najboljima u svijetu. prodaja plug-in automobila.</p>
            
            <img src="Slike/model%20x.jpg">
        </main>
        
        <?php include "bocni.php" ?>
        
        <?php include "dno.php" ?>