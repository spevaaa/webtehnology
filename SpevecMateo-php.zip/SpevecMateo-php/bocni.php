<aside>
            <h1>Zanimljivosti</h1>
            
            <ol>
                <li>Tesla Model Y je naprodavaniji automobil</li>
                <li>Odlični rezultati na sigurnosnim testovima</li>
                <li>Tesle su zapravo štetne za okoliš</li>
                <li>Ne zahtjevaju preveliko održavanje</li>
            </ol>
        </aside>