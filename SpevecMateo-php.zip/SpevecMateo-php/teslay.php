<?php include "pocetak.php" ?>
            <h1>Tesla Model Y</h1>
            <p>Tesla Model Y je baterijski električni kompaktni crossover kojeg proizvodi Tesla, Inc. Predstavljen u ožujku 2019., započeo je s proizvodnjom u svojoj tvornici u Fremontu u siječnju 2020., a isporuka je započela 13. ožujka 2020.</p>
            <p>Model Y temelji se na platformi limuzine Model 3. Procjenjuje se da dijeli oko 75 posto svojih dijelova s Tesla Modelom 3, što uključuje sličan dizajn interijera i eksterijera te električni pogon. Model Y ispunjava manji i jeftiniji segment od Tesla Model X srednje veličine.</p>
            <p>Dana 14. ožujka 2019. Elon Musk je premijerno predstavio Tesla Model Y na događaju u Teslinom dizajnerskom studiju u Hawthorneu, CA, gdje su najavljene specifikacije i prikazano vozilo. Poslije prezentacije sudionicima su također ponuđene testne vožnje više vozila Model Y. Zbog svoje veće veličine, Y troši više energije od 3, pa stoga ima kraći domet. Tvornica u Fremontu je promijenjena kako bi se prilagodila proizvodnji Y.</p>
            
            <h1>Unutrašnjost iz budućnosti</h1>
            
            <img src="Slike/model%20y.jpg">
        </main>
        
        <?php include "bocni.php" ?>
        
        <?php include "dno.php" ?>