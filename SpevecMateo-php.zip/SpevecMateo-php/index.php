<?php include "pocetak.php" ?>
            <h1>Općenito o Tesli</h1>
            <p>Tesla je američka automobilistička tvrtka sa sjedištem u Palo Altu, savezna država Kalifornija koja proizvodi električne automobile.</p>
            <p>Teslu (osnovanu kao Tesla Motors) su osnovali 1. srpnja 2003. Martin Eberhard i Mark Tarpenning. U veljači 2004. trojica osnivača su prikupila ulaganje od 7,5 milijuna dolara, a Elon Musk je uložio 6,5 milijuna dolara. Musk je postao predsjednik upravnog odbora i imenovao Eberharda za izvršnog direktora.</p>
            <p>Prototipovi prvog automobila Tesla su službeno predstavljeni javnosti 19. srpnja 2006. u Santa Monici (Kalifornija). Musk je 2006. uspio prikupiti 100 milijuna dolara. Kao rezultat toga, Tesla je 2008. godine započela proizvodnju svog prvog Roadstera.</p>
            
            <iframe width="560" height="315" src="https://www.youtube.com/embed/XB2g7-HgE_g" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </main>
        
        <?php include "bocni.php" ?>
        
        <?php include "dno.php" ?>